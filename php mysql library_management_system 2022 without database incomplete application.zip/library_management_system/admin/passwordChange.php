<?php
session_start();

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

$msg1 ="";

$id=$_SESSION['id'];

if(isset($_POST['submit']))
{
 $old_pass=($_POST['old_pass']);
 $new_pass=($_POST['new_pass']);
 
$sql=mysqli_query($connect,"SELECT password FROM admins where password='$old_pass' && id='$id'");
$num=mysqli_fetch_array($sql);

if($num>0)
{
 $con=mysqli_query($connect,"update admins set password='$new_pass' where id='$id'");
$_SESSION['msg1']="Password Changed Successfully !!";
}
else
{
$_SESSION['msg1']="Old Password not match !!";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../passwordChange.css">
    <title>ADMIN PASSWORD CHANGE</title>
</head>
<body>
<div class="container-fluid">

<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="admin_dashboard.php"><img style="width:30px;" src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>

                    </div>
</nav>

        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>
<br></br>
<div class="pass-changeForm" style="width:600px;margin:auto;border-radius:20px;box-shadow:2px 4px 6px black;border:2px solid green;padding:20px;text-align:center;">
<form action="" method="POST">
    <h3 style="color:white;background-color:#10bccc;padding:8px;">Change Your Password</h3>
    <p style="color:red;"><?php echo $_SESSION['msg1']="";?></p>
    <input type="text" name="name" value="<?php echo $row['name']; ?>" disabled style="width:80%;color:white;border:none;padding:8px;border-radius:8px;">
    <br><br>
    <input type="email" name="email" value="<?php echo $row['email']; ?>" disabled style="width:80%;color:white;border:none;padding:8px;border-radius:8px;">
    <br><br>
    <input type="password" name="old_pass" placeholder="Enter Old Password" style="width:80%;border:none;padding:8px;border-radius:8px;">
    <br><br>
    <input type="password" name="new_pass" placeholder="Enter New Password" style="width:80%;border:none;padding:8px;border-radius:8px;">
    <br><br>
    <!-- <input type="password" name="conf_new_pass" placeholder="Enter New Password Again" style="width:80%;border:none;padding:8px;border-radius:8px;">
    <br><br> -->
    <input type="submit" name="submit" id="submitBtn" value="Change Password" style="width:80%;box-shadow:2px 4px 6px black;border:none;padding:8px;border-radius:8px;background-color:#258c06;color:white;font-size:1.3rem;font-weight:600;">

</form>
</div>
<br></br><br></br>
    <footer>
        <div class="foot">
            <a href="#"><h6>Copyright By LBMS</h6></a>
        </div>
    </footer>
</div>

<script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>