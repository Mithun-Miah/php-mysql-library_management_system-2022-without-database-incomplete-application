<?php
// For Store data
session_start();

$msg=$name=$ad_id=$email= "";

$connect = mysqli_connect('localhost', 'root', '', 'library_management');
if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}
// For Secure URL / do not permission enter by url type
if($_SESSION['name'] == true){
    // after login fetch email address and password display from database into this page
    $msg = "Name : $_SESSION[name]";
    $msg3 = "Email : $_SESSION[email]";
} else{
    header('Location: index.php');
}
$sl_no = "";
$book_id = "";
$b_title = "";
$author_name = "";
$publisher_name = "";
$category = "";
$issued_by = "";
$issued_for = "";
$issue_date = "";

$query = "select * from issue_book";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <title>ISSUED BOOKS LIST</title>

    <STYle>
                /* navbar css start */
        #navbarSupportedContent {
            text-align: right !important;
            display: inline !important;
            margin-left: 700px;
            width: 300px;
        }
        .navbar-brand img{
            width: 40px;
            height: 50px;
        }
        .nav-link {
            color: white !important;
        }
        .nav-link:hover {
            color: chartreuse !important;
        }
        /* navbar css end */
        /* title section css start */
        .title-slide{
            border-left: 4px solid red;
            border-right: 4px solid red;
        }
        /* title section css end */
        .admin-info{
            height:100vh;
        }

        /* Footer section css start */
        .foot{
            background-color: rgb(71, 70, 70);
            color: white;
            padding: 10px;
            text-align: center;
        }
        .foot a{
            text-decoration: none;
        }
        .foot a:hover{
            color: orange;
        }

        /* Footer section css end */
    </STYle>

</head>
<body>
    <div class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="admin_dashboard.php"><img style="width:30px;" src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                    </div>
</nav>

<div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

    <div class="admin-info" style="text-align:center;">
            <h4 style="text-align:center;color:green;font-weight:700;">Issued Books List</h4>
            <div class="row">
                <div class="col-md-12">
                    <form action="">
                        <table class="table-bordered">
                            <tr style="text-align:center;">
                                <th style="padding:5px;">SL. No.</th>
                                <th style="padding:5px;">Book Id</th>
                                <th style="padding:5px;">Book Title</th>
                                <th style="padding:5px;">Author Name</th>
                                <th style="padding:5px;">Publisher Name</th>
                                <th style="padding:5px;">Category</th>
                                <th style="padding:5px;">Issued By</th>
                                <th style="padding:5px;">Issued For</th>
                                <th style="padding:5px;">Issued Date</th>
                            </tr>

                            <?php
                                $query_run = mysqli_query($connect,$query);
                                while($row = mysqli_fetch_array($query_run)){
                                    $sl_no = $row['id'];
                                    $book_id = $row['book_id'];
                                    $b_title = $row['b_title'];
                                    $author_name = $row['author_name'];
                                    $publisher_name = $row['publisher_name'];
                                    $category = $row['category'];
                                    $issued_by = $row['issued_by'];
                                    $issued_for = $row['issued_for'];
                                    $issue_date = $row['issue_date'];

                                    ?>
                                    <tr>
                                        <td style="padding:2px;"><?php echo $sl_no; ?></td>
                                        <td style="padding:2px;"><?php echo $book_id; ?></td>
                                        <td style="padding:2px;"><?php echo $b_title; ?></td>
                                        <td style="padding:2px;"><?php echo $author_name; ?></td>
                                        <td style="padding:2px;"><?php echo $publisher_name; ?></td>
                                        <td style="padding:2px;"><?php echo $category; ?></td>
                                        <td style="padding:2px;"><?php echo $issued_by; ?></td>
                                        <td style="padding:2px;"><?php echo $issued_for; ?></td>
                                        <td style="padding:2px;"><?php echo $issue_date; ?></td>
                                    </tr>
                            <?php
                            }
                            ?>

                        </table>
                    </form>

                </div>
            </div>
    </div>

    <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>

    </div>

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>