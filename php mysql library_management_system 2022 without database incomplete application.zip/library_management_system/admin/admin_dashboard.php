<?php
require("functions.php");
// For Store data
session_start();

$connect = mysqli_connect('localhost', 'root', '', 'library_management');
if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

$msg = "";
// For Secure URL / do not permission enter by url type
if($_SESSION['name'] == true){
    // after login fetch email address and password display from database into this page
    $msg = "Welcome : $_SESSION[name]";
} else{
    header('Location: index.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="user_main_window.css"> -->
    <title>Admin Panel</title>

    <style>
                /* navbar css start */
        #navbarSupportedContent {
            text-align: right !important;
            display: inline !important;
            margin-left: 700px;
            width: 300px;
        }
        .navbar-brand img{
            width: 40px;
            height: 50px;
        }
        .nav-link {
            color: white !important;
        }
        .nav-link:hover {
            color: chartreuse !important;
        }
        /* navbar css end */
        /* title section css start */
        .title-slide{
            border-left: 4px solid red;
            border-right: 4px solid red;
        }
        /* title section css end */
        /*company-info section css start*/


        /*company-info section css end*/

        /* Footer section css start */
        .foot{
            background-color: rgb(71, 70, 70);
            color: white;
            padding: 10px;
            text-align: center;
        }
        .foot a{
            text-decoration: none;
        }
        .foot a:hover{
            color: orange;
        }

        /* Footer section css end */
    </style>
</head>
<body>

<div class="container-fluid">
<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="admin_dashboard.php"><img style="width:30px;" src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                    </div>
</nav>

                    <div class="title-slide">
                            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
                    </div>

                    <div class="middle-section">
                        <div class="company-info" style="display:flex; justify-content:center; align-items:center;">
                            <img style="width:120px;" src="../icons_library_app/library_logo.jpg" alt="company_logo">
                            <article style="background-color:yellow;padding:10px;">
                                <h4>DEVELOPMENT DESIGN CONSULTANTS LTD.</h4>
                                <h5>"DDC Center", 47 Mohakhali C/A, Dhaka-1212, Bangladesh"</h5>
                                <marquee behavior="" direction="">For Support Please Call +88 01911601021 , +88 01966167016 | You Have To Archive The Daily Backups In a Secondary Storage ( Like Pen Drive or External HDD ) And Keep In a Safe Place.
                                </marquee>
                            </article>
                        </div>
                        <br>
                        <p style="text-shadow: 1px 2px 2px black;color:green;padding:5px;text-align:center;font-weight:600;font-size:1.5rem;">
                            <?php echo $msg; ?>
                        </p>

                    <div class="work-section" style="display:flex;justify-content:center;align-items:center;gap: 50px;">

                        <a href="view_profile.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/profile_icon.png" alt="user-profile-icon">
                            <h5 style="text-align:center;">View Profile</h5>
                        </a>

                        <a href="edit_profile.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/user_update.png" alt="user-profile-update-icon">
                            <h5 style="text-align:center;">Update Profile</h5>
                        </a>

                        <!-- <a href="entryMenu.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/book.jpg" alt="book-icon">
                            <h5 style="text-align:center;">Entry Menu</h5>
                        </a> -->

                        <a href="passwordChange.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/key.png" alt="key-icon">
                            <h5 style="text-align:center;">Change Password</h5>
                        </a>
                    </div>
                    <br>

                    <h3 style="text-align:center; color:green;font-weight:800;text-shadow:2px 1px 2px black;">Admin Management Menu</h3>

                    <div class="work-section" style="display:flex;justify-content:center;align-items:center;gap: 50px;">
                        <a href="book_menu.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/profile_icon.png" alt="user-profile-icon">
                            <h5 style="text-align:center;">Books Menu</h5>
                        </a>

                        <a href="authors_menu.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/user_update.png" alt="user-profile-update-icon">
                            <h5 style="text-align:center;">Authors Menu</h5>
                        </a>

                        <a href="publishers_menu.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/book.jpg" alt="book-icon">
                            <h5 style="text-align:center;">Publishers Menu</h5>
                        </a>

                        <a href="category_menu.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/category.png" alt="category-icon">
                            <h5 style="text-align:center;">Category Menu</h5>
                        </a>

                        <a href="issue_book.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="../icons_library_app/issue_book.png" alt="issue_book-icon">
                            <h5 style="text-align:center;">Issue Books</h5>
                        </a>
                    
                    </div>
                    <br>

                    <h3 style="text-align:center; color:green;font-weight:800;text-shadow:2px 1px 2px black;">Display All Activity</h3>
                    <br>
                    <div class="work-section" style="display:flex;justify-content:center;align-items:center;gap: 50px;">

                        <div class="card border-success mb-3" style="width: 300px;">
                            <div class="card-header bg-transparent border-success text-center">Books</div>
                                <div class="card-body text-success">
                                    <p class="card-title">Total Added Books: <?php echo get_book_add_count(); ?> </p>
                                </div>
                        <a href="view_booksAdded.php" target="_blank" class="btn btn-primary">View All Added Books</a>
                        </div>

                        <div class="card border-success mb-3" style="width: 300px;">
                            <div class="card-header bg-transparent border-success text-center">Author</div>
                                <div class="card-body text-success">
                                    <p class="card-title">Total Added Author: <?php echo get_author_count(); ?> </p>
                                </div>
                        <a href="view_authorsAdded.php" target="_blank" class="btn btn-info">View All Added Author</a>
                        </div>

                        <div class="card border-success mb-3" style="width: 300px;">
                            <div class="card-header bg-transparent border-success text-center">Publisher</div>
                                <div class="card-body text-success">
                                    <p class="card-title">Total Added Publisher: <?php echo get_publisher_count(); ?> </p>
                                </div>
                        <a href="view_publishersAdded.php" target="_blank" class="btn btn-success">View All Added Publisher</a>
                        </div>

                        <div class="card border-success mb-3" style="width: 300px;">
                            <div class="card-header bg-transparent border-success text-center">Category</div>
                                <div class="card-body text-success">
                                    <p class="card-title">Total Added Category: <?php echo get_category_count(); ?> </p>
                                </div>
                        <a href="view_categoryAdded.php" target="_blank" class="btn btn-warning">View All Added Category</a>
                        </div>
                    
                    </div>

                    <div class="work-section" style="display:flex;justify-content:center;align-items:center;gap: 50px;">

                        <div class="card border-success mb-3" style="width: 300px;">
                            <div class="card-header bg-transparent border-success text-center">Issue Books</div>
                                <div class="card-body text-success">
                                    <p class="card-title">Total Book Issued: <?php echo get_issue_book_count(); ?> </p>
                                </div>
                                    <a href="view_issueBookAdded.php" target="_blank" class="btn btn-danger">View All Book Issued</a>
                        </div>

                        <div class="card border-success mb-3" style="width: 300px;">
                            <div class="card-header bg-transparent border-success text-center">Registered Users</div>
                                <div class="card-body text-success">
                                    <p class="card-title">Total Registered Users: <?php echo get_reg_user_count(); ?> </p>
                                </div>
                                    <a href="view_RegUserAdded.php" target="_blank" class="btn btn-secondary">View All Registered Users</a>
                        </div>
                            
                    </div>
                    <br><br><br><br><br>
    <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>
</div>    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>