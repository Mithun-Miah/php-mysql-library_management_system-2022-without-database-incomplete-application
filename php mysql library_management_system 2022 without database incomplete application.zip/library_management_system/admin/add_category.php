<?php
// For Store data
session_start();

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

if(isset($_POST['submit'])){

    $category_name = $_POST['category_name'];

    if($category_name == ""){
        echo "<script>alert('Please Enter Category Name Correctly')</script>";
    }else{

        $insert = "INSERT INTO category(category_name) VALUES ('$category_name')";
        
            $insert_query = mysqli_query($connect,$insert);
        
            if($insert_query){
                echo "<script>alert('Category Added Successful')</script>";
                //header("location: add_book.php");
            }else{
                echo "<script>alert('Category Added Unsuccessful')</script>";
            }

    }
                
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="user_main_window.css"> -->
    <title>Add Category</title>

    <style>
                /* navbar css start */
        #navbarSupportedContent {
            text-align: right !important;
            display: inline !important;
            margin-left: 700px;
            width: 300px;
        }
        .navbar-brand img{
            width: 40px;
            height: 50px;
        }
        .nav-link {
            color: white !important;
        }
        .nav-link:hover {
            color: chartreuse !important;
        }
        /* navbar css end */
        /* title section css start */
        .title-slide{
            border-left: 4px solid red;
            border-right: 4px solid red;
        }
        /* title section css end */
        /*company-info section css start*/


        /*company-info section css end*/

        /* Footer section css start */
        .foot{
            background-color: rgb(71, 70, 70);
            color: white;
            padding: 10px;
            text-align: center;
        }
        .foot a{
            text-decoration: none;
        }
        .foot a:hover{
            color: orange;
        }

        /* Footer section css end */
    </style>
</head>
<body>

<div class="container-fluid">
<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="admin_dashboard.php"><img style="width:30px;" src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                    </div>
</nav>

                    <div class="title-slide">
                            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
                    </div>

                    <div class="work-section" style="margin:auto;border:1px solid red;padding:10px;">
                        <h4 style="text-align:center;">Add Category</h4>
                        <!-- <p style="text-shadow: 1px 2px 2px black;color:red;padding:5px;text-align:center;font-weight:600;font-size:1.2rem;">
                            <?php echo $msg; ?>
                        </p> -->
                        <form action="" method="post" style="margin:auto;padding:10px;width:60%;border:1px solid green;">
                            <label for="" style="text-align:left;">Category ID</label>
                            <br>
                            <input type="text" name="category_id" style="width:100%;" disabled>
                            <label for="" style="text-align:left;">Category Name</label>
                            <br>
                            <input type="text" name="category_name" style="width:100%;">
                            <br><br>
                            <button name="submit" style="width:100%;background-color:green;color:white;font-size:1.3rem;font-weight:700;border:none;box-shadow:2px 2px 2px black;">Add Category</button>
                        </form>
                        

                    </div>
                    
                    <br><br><br><br><br>
    <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>
</div>    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>