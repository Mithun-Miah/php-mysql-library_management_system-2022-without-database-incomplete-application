<?php
// For Store data
session_start();

// $msg=$name=$em_id=$email= "";

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

$password = "";

$query = "SELECT * FROM admins WHERE email = '$_SESSION[email]'";

$query_run = mysqli_query($connect,$query);
while($row = mysqli_fetch_array($query_run)){
    $password = $row['password'];
}
if($password == $_POST['old_password']){
    $query = "update admins set password = '$POST[new_password]'
    where email = '$_SESSION[email]'";
    $query_run = mysqli_query($connect,$query);
}

?>

<script>
    alert("Updated Successful");
    //window.location.href = "passwordChange.php";
</script>