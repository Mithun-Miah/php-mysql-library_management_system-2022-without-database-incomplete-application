<?php
function get_book_add_count(){
    $connect = mysqli_connect('localhost', 'root', '', 'library_management');
    $books_count = "";
    $query = "select count(*) as books_count from book_entry";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $books_count = $row['books_count'];
    }
    return($books_count);
}

function get_author_count(){
    $connect = mysqli_connect('localhost', 'root', '', 'library_management');
    $authors_count = "";
    $query = "select count(*) as authors_count from authors";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $authors_count = $row['authors_count'];
    }
    return($authors_count);
}

function get_publisher_count(){
    $connect = mysqli_connect('localhost', 'root', '', 'library_management');
    $publishers_count = "";
    $query = "select count(*) as publishers_count from publishers";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $publishers_count = $row['publishers_count'];
    }
    return($publishers_count);
}

function get_category_count(){
    $connect = mysqli_connect('localhost', 'root', '', 'library_management');
    $category_count = "";
    $query = "select count(*) as category_count from category";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $category_count = $row['category_count'];
    }
    return($category_count);
}

function get_issue_book_count(){
    $connect = mysqli_connect('localhost', 'root', '', 'library_management');
    $issue_books_count = "";
    $query = "select count(*) as issue_books_count from issue_book";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $issue_books_count = $row['issue_books_count'];
    }
    return($issue_books_count);
}

function get_reg_user_count(){
    $connect = mysqli_connect('localhost', 'root', '', 'library_management');
    $reg_users_count = "";
    $query = "select count(*) as reg_users_count from user_register";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $reg_users_count = $row['reg_users_count'];
    }
    return($reg_users_count);
}

?>