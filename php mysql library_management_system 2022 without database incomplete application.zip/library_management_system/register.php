<?php
// For Store data
session_start();

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

$msg = "";

if($connect){
    //echo "<script>alert('Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

if(isset($_POST['reg_btn'])){
    $name = $_POST['name'];
    $dept_name = $_POST['dept_name'];
    $em_id = $_POST['em_id'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];

    $select = "SELECT * FROM user_register WHERE em_id = '$em_id' AND email = '$email'";
    $query = mysqli_query($connect,$select);
    $run = mysqli_num_rows($query);

    $select2 = "SELECT * FROM user_register";
    $query2 = mysqli_query($connect,$select2);
    $run2 = mysqli_num_rows($query2);

    if($name == "" ||$dept_name==""||$em_id==""||$email==""||$password==""||$c_password==""){
        $msg = "Please Fillup All Information Correctly";
    }else{
        if($password != $c_password){
            $msg = "Password Not Match";
        }else{
            if($run>0){
                echo "<script>alert('User Already Exist')</script>";
            }else{
                $insert = "INSERT INTO user_register(name,dept_name,em_id,email,password,c_password)
                VALUES ('$name','$dept_name','$em_id','$email','$password','$c_password')";
        
                $insert_query = mysqli_query($connect,$insert);
        
                if($insert_query){
                    echo "<script>alert('Registration Successful')</script>";
                    header("location: index.php");
                }else{
                    echo "<script>alert('Registration Unsuccessful')</script>";
                }
        
            }
        }
        
    }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="register.css">
    <title>LBMS</title>
</head>
<body>

    <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"><img src="icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="register.php">Register</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="admin/index.php">Admin Login</a>
                        </li>
                    </ul>
                    </div>
                </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">
        
        <div class="left-side">
            <h5>*** Opening Time ***</h5>
            <p>From Morning 8:30AM </p>
            <h5>*** Closing Time ***</h5>
            <p>Evening 5:30PM </p>
        </div>

        <div class="right-side">
            <h5>Registration</h5>
            <p style="text-shadow: 1px 2px 2px black;color:red;padding:5px;text-align:center;font-weight:600;font-size:1.2rem;">
                <?php echo $msg; ?>
            </p>
            <form method="POST">
            <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Full Name</label>
                    <input type="name" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Department Name</label>
                    <input type="name" name="dept_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Employee Id</label>
                    <input type="name" name="em_id" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
                    <input type="password" name="c_password" class="form-control" id="exampleInputPassword1">
                </div>
                <button type="submit" name="reg_btn" id="reg_btn" class="btn btn-primary">Register</button>
            </form>
        </div>
        
        </div>
        
        <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>
        
    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>